// routes/payment.js
const express = require('express');
const router = express.Router();
const moment = require('moment');
const crypto = require('crypto');
const qs = require('qs');
const Order = require('../models/Order'); // Model đơn hàng

// Hàm sắp xếp các tham số theo thứ tự bảng chữ cái
function sortObject(obj) {
  const sorted = {};
  Object.keys(obj)
    .sort()
    .forEach(key => {
      sorted[key] = encodeURIComponent(obj[key]).replace(/%20/g, "+");
    });
  return sorted;
}

/**
 * GET: Xử lý IPN callback từ VNPay
 * Endpoint: /api/payment/vnpay_ipn
 */
// router.get('/vnpay_ipn', async (req, res, next) => {
//   console.log('req.query from SIT Testing:', req.query);
//   try {
//     // 1. Lấy các tham số từ query (VNPay gửi qua GET)
//     let vnp_Params = req.query;
//     // Lưu lại chữ ký nhận được
//     const secureHash = vnp_Params['vnp_SecureHash']?.trim();

//     // 2. Xoá các trường không cần thiết
//     delete vnp_Params['vnp_SecureHash'];
//     delete vnp_Params['vnp_SecureHashType'];

//     // 3. Sắp xếp các tham số theo thứ tự bảng chữ cái
//     vnp_Params = sortObject(vnp_Params);

//     // 4. Tạo chuỗi dữ liệu ký
//     const signData = qs.stringify(vnp_Params, { encode: false });
//     const secretKey = process.env.VNP_HASH_SECRET; // Đảm bảo key đúng từ .env
//     const hmac = crypto.createHmac("sha512", secretKey);
//     const signed = hmac.update(Buffer.from(signData, 'utf-8')).digest("hex");

//     // 5. So sánh chữ ký nhận được và chữ ký tính toán
//     if (secureHash === signed) {
//       // Chữ ký hợp lệ, kiểm tra mã phản hồi từ VNPay
//       if (vnp_Params['vnp_ResponseCode'] === '00') {
//         // Giao dịch thành công: cập nhật trạng thái đơn hàng
//         const txnRef = vnp_Params['vnp_TxnRef'];
//         // Ví dụ: tìm Order có _id kết thúc bằng txnRef (nếu bạn dùng last 6 ký tự của _id làm txnRef)
//         await Order.findOneAndUpdate({ _id: { $regex: txnRef + '$' } }, { payment_status: 'Paid' });
//         console.log(`Payment success for order reference: ${txnRef}`);
//       } else {
//         // Giao dịch thất bại hoặc bị hủy
//         console.log(`Payment failed or cancelled. Response code: ${vnp_Params['vnp_ResponseCode']}`);
//       }
//       return res.status(200).json({ RspCode: '00', Message: 'IPN Success' });
//     } else {
//       console.error("Invalid signature in VNPay IPN callback");
//       return res.status(400).json({ RspCode: '97', Message: 'Invalid signature' });
//     }
//   } catch (error) {
//     next(error);
//   }
// });

router.get('/vnpay_ipn', async (req, res, next) => {
  try {
    // Lấy tham số từ query (VNPay gửi qua GET)
    let vnp_Params = req.query;
    console.log("VNPay IPN params:", vnp_Params);

    // Tạm thời bỏ qua kiểm tra chữ ký
    // const secureHash = vnp_Params['vnp_SecureHash'];
    // delete vnp_Params['vnp_SecureHash'];
    // delete vnp_Params['vnp_SecureHashType'];
    // vnp_Params = sortObject(vnp_Params);
    // const signData = qs.stringify(vnp_Params, { encode: false });
    // const hmac = crypto.createHmac("sha512", process.env.VNP_HASH_SECRET);
    // const signed = hmac.update(Buffer.from(signData, 'utf-8')).digest("hex");
    // if (secureHash !== signed) {
    //   console.error("Invalid signature in VNPay IPN callback");
    //   return res.status(400).json({ RspCode: '97', Message: 'Invalid signature' });
    // }

    // Ví dụ: Cập nhật đơn hàng (ở đây bạn có thể thêm logic cập nhật trạng thái thanh toán vào database)
    // Nếu bạn dùng vnp_TxnRef để nhận dạng đơn hàng, ví dụ:
    const txnRef = vnp_Params['vnp_TxnRef'];
    // Đây là ví dụ update đơn hàng (bạn cần điều chỉnh logic theo model của bạn)
    // await Order.findOneAndUpdate({ _id: { $regex: txnRef + '$' } }, { payment_status: 'Paid' });
    console.log(`Payment success for order reference: ${txnRef}`);

    // Phản hồi lại cho VNPay rằng bạn đã nhận được kết quả thanh toán thành công
    return res.status(200).json({ RspCode: '00', Message: 'IPN Success (signature skipped)' });
  } catch (error) {
    next(error);
  }
});



module.exports = router;
